/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "tqcombobox.h"
#include "tqlineedit.h"
#include "tqtreeview.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionImport_Audio_Files;
    QAction *actionChoose_Export_Folder;
    QAction *actionShow_export_folder;
    QAction *actionRemove_selected_files;
    QAction *actionRemove_all_files;
    QAction *actionRemove_finished_files;
    QAction *actionProcess;
    QAction *actionImport_folder;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QPushButton *buttonExportTo;
    TqLineEdit *lineEditExportTo;
    TqComboBox *comboBoxDSP;
    TqTreeView *treeViewImportedFiles;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *buttonProcessFiles;
    TqComboBox *comboBoxRemoveFiles;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuEdit;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(400, 300);
        actionImport_Audio_Files = new QAction(MainWindow);
        actionImport_Audio_Files->setObjectName(QStringLiteral("actionImport_Audio_Files"));
        actionChoose_Export_Folder = new QAction(MainWindow);
        actionChoose_Export_Folder->setObjectName(QStringLiteral("actionChoose_Export_Folder"));
        actionShow_export_folder = new QAction(MainWindow);
        actionShow_export_folder->setObjectName(QStringLiteral("actionShow_export_folder"));
        actionRemove_selected_files = new QAction(MainWindow);
        actionRemove_selected_files->setObjectName(QStringLiteral("actionRemove_selected_files"));
        actionRemove_all_files = new QAction(MainWindow);
        actionRemove_all_files->setObjectName(QStringLiteral("actionRemove_all_files"));
        actionRemove_finished_files = new QAction(MainWindow);
        actionRemove_finished_files->setObjectName(QStringLiteral("actionRemove_finished_files"));
        actionProcess = new QAction(MainWindow);
        actionProcess->setObjectName(QStringLiteral("actionProcess"));
        actionImport_folder = new QAction(MainWindow);
        actionImport_folder->setObjectName(QStringLiteral("actionImport_folder"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        buttonExportTo = new QPushButton(centralWidget);
        buttonExportTo->setObjectName(QStringLiteral("buttonExportTo"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(buttonExportTo->sizePolicy().hasHeightForWidth());
        buttonExportTo->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(buttonExportTo);

        lineEditExportTo = new TqLineEdit(centralWidget);
        lineEditExportTo->setObjectName(QStringLiteral("lineEditExportTo"));

        horizontalLayout->addWidget(lineEditExportTo);

        comboBoxDSP = new TqComboBox(centralWidget);
        comboBoxDSP->setObjectName(QStringLiteral("comboBoxDSP"));

        horizontalLayout->addWidget(comboBoxDSP);


        verticalLayout->addLayout(horizontalLayout);

        treeViewImportedFiles = new TqTreeView(centralWidget);
        treeViewImportedFiles->setObjectName(QStringLiteral("treeViewImportedFiles"));

        verticalLayout->addWidget(treeViewImportedFiles);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        buttonProcessFiles = new QPushButton(centralWidget);
        buttonProcessFiles->setObjectName(QStringLiteral("buttonProcessFiles"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(buttonProcessFiles->sizePolicy().hasHeightForWidth());
        buttonProcessFiles->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(buttonProcessFiles);

        comboBoxRemoveFiles = new TqComboBox(centralWidget);
        comboBoxRemoveFiles->setObjectName(QStringLiteral("comboBoxRemoveFiles"));
        sizePolicy.setHeightForWidth(comboBoxRemoveFiles->sizePolicy().hasHeightForWidth());
        comboBoxRemoveFiles->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(comboBoxRemoveFiles);


        verticalLayout->addLayout(horizontalLayout_2);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 22));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QStringLiteral("menuEdit"));
        MainWindow->setMenuBar(menuBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuFile->addAction(actionImport_Audio_Files);
        menuFile->addAction(actionImport_folder);
        menuFile->addSeparator();
        menuFile->addAction(actionChoose_Export_Folder);
        menuFile->addAction(actionShow_export_folder);
        menuEdit->addAction(actionRemove_all_files);
        menuEdit->addAction(actionRemove_selected_files);
        menuEdit->addAction(actionRemove_finished_files);
        menuEdit->addSeparator();
        menuEdit->addAction(actionProcess);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionImport_Audio_Files->setText(QApplication::translate("MainWindow", "import audio files...", 0));
        actionImport_Audio_Files->setShortcut(QApplication::translate("MainWindow", "Ctrl+I", 0));
        actionChoose_Export_Folder->setText(QApplication::translate("MainWindow", "choose export folder...", 0));
        actionChoose_Export_Folder->setShortcut(QApplication::translate("MainWindow", "Ctrl+E", 0));
        actionShow_export_folder->setText(QApplication::translate("MainWindow", "show export folder", 0));
        actionShow_export_folder->setShortcut(QApplication::translate("MainWindow", "Ctrl+F", 0));
        actionRemove_selected_files->setText(QApplication::translate("MainWindow", "remove selected", 0));
        actionRemove_all_files->setText(QApplication::translate("MainWindow", "remove all", 0));
        actionRemove_finished_files->setText(QApplication::translate("MainWindow", "remove finished", 0));
        actionProcess->setText(QApplication::translate("MainWindow", "process...", 0));
        actionProcess->setShortcut(QApplication::translate("MainWindow", "Ctrl+Shift+P", 0));
        actionImport_folder->setText(QApplication::translate("MainWindow", "import folder...", 0));
        actionImport_folder->setShortcut(QApplication::translate("MainWindow", "Ctrl+Shift+I", 0));
        buttonExportTo->setText(QApplication::translate("MainWindow", "export to...", 0));
        buttonProcessFiles->setText(QApplication::translate("MainWindow", "process files", 0));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", 0));
        menuEdit->setTitle(QApplication::translate("MainWindow", "Edit", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
